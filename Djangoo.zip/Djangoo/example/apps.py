from django.apps import AppConfig


class ExampleConfig(AppConfig):
    name = 'example'
    # альтернативная имя модели
    verbose_name = 'Известные люди'
